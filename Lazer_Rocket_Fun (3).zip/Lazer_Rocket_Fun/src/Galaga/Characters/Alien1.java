package Galaga.Characters;

import java.awt.Graphics;

/**
 * @author Brian
 */
public class Alien1 extends Alien {
    
    public Alien1(Graphics page) {
        super(page);
    }
}
