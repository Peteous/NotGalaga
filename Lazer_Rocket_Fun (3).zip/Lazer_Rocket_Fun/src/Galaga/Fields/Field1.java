package Galaga.Fields;

import java.awt.Graphics;

/**
 * @author Brian
 */
public class Field1 extends Field {
    //yes, this class is absoultely necessary
    public Field1(Graphics page) {
        super(page);
    }
}
